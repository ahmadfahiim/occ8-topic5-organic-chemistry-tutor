/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 *
 * @author User
 */
public class PEventPageController {
    
   
    @FXML
    Button p1;
    @FXML
    Button p2;
    @FXML
    Button p3;
    @FXML
    Button p4;
    @FXML
    Button p5;
    @FXML
    Button p6;
    @FXML
    Button p7;
    @FXML
    Button p8;
    @FXML
    Button p9;
    
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    parent st = new parent();
    Distance dist = new Distance(); 
    
    @FXML
    public void viewProfileButton(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("PMainScreen.fxml"));
        root = loader.load();

        PMainScreenController smsc = loader.getController();
        smsc.displayName(st.getUsername());
        smsc.displayEmail(st.getEmail());
        smsc.displayX(st.getXCoordinate());
        smsc.displayY(st.getYCoordinate());
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();  
    }
    
    @FXML
    public void discussionPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("PDiscussionPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void logoutButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("Landing.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void setP1(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("PBookEvent.fxml"));
        root = loader.load();
        PBookEventController pbec = loader.getController();
      
        pbec.displayPlace("Petrosains Science Discovery Centre");
        Event ev = new Event(st.getUsername());
        
        pbec.displayDistance(String.format("%.2f", dist.PetroSc(Double.parseDouble(st.getXCoordinate()), Double.parseDouble(st.getYCoordinate()))));
        
        pbec.display1(ev.getS1());
        pbec.display2(ev.getS2());
        pbec.display3(ev.getS3());
        pbec.display4(ev.getS4());
        pbec.display5(ev.getS5());
        pbec.display6(ev.getS6());

        
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void setP2(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("PBookEvent.fxml"));
        root = loader.load();
        PBookEventController pbec = loader.getController();
        
        pbec.displayPlace("Tech Dome Penang");
        Event ev = new Event(st.getUsername());
        
        pbec.displayDistance(String.format("%.2f", dist.Tech(Double.parseDouble(st.getXCoordinate()), Double.parseDouble(st.getYCoordinate()))));
        
        pbec.display1(ev.getS1());
        pbec.display2(ev.getS2());
        pbec.display3(ev.getS3());
        pbec.display4(ev.getS4());
        pbec.display5(ev.getS5());
        pbec.display6(ev.getS6());
        
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void setP3(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("PBookEvent.fxml"));
        root = loader.load();
        PBookEventController pbec = loader.getController();
        
        pbec.displayPlace("Agro Technology Park in MARDI");
        Event ev = new Event(st.getUsername());
        
        pbec.displayDistance(String.format("%.2f", dist.Agro(Double.parseDouble(st.getXCoordinate()), Double.parseDouble(st.getYCoordinate()))));
        
        pbec.display1(ev.getS1());
        pbec.display2(ev.getS2());
        pbec.display3(ev.getS3());
        pbec.display4(ev.getS4());
        pbec.display5(ev.getS5());
        pbec.display6(ev.getS6());
        
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void setP4(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("PBookEvent.fxml"));
        root = loader.load();
        PBookEventController pbec = loader.getController();
        
        pbec.displayPlace("National Science Centre");
        Event ev = new Event(st.getUsername());
        
        pbec.displayDistance(String.format("%.2f", dist.National(Double.parseDouble(st.getXCoordinate()), Double.parseDouble(st.getYCoordinate()))));
        
        pbec.display1(ev.getS1());
        pbec.display2(ev.getS2());
        pbec.display3(ev.getS3());
        pbec.display4(ev.getS4());
        pbec.display5(ev.getS5());
        pbec.display6(ev.getS6());
        
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void setP5(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("PBookEvent.fxml"));
        root = loader.load();
        PBookEventController pbec = loader.getController();
        
        pbec.displayPlace("Marine Aquarium and Museum");
        Event ev = new Event(st.getUsername());
        
        pbec.displayDistance(String.format("%.2f", dist.Marine(Double.parseDouble(st.getXCoordinate()), Double.parseDouble(st.getYCoordinate()))));
        
        pbec.display1(ev.getS1());
        pbec.display2(ev.getS2());
        pbec.display3(ev.getS3());
        pbec.display4(ev.getS4());
        pbec.display5(ev.getS5());
        pbec.display6(ev.getS6());
        
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void setP6(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("PBookEvent.fxml"));
        root = loader.load();
        PBookEventController pbec = loader.getController();
        
        pbec.displayPlace("Pusat Sains & Kreativiti Terengganu");
        Event ev = new Event(st.getUsername());
        
        pbec.displayDistance(String.format("%.2f", dist.Pusat(Double.parseDouble(st.getXCoordinate()), Double.parseDouble(st.getYCoordinate()))));
        
        pbec.display1(ev.getS1());
        pbec.display2(ev.getS2());
        pbec.display3(ev.getS3());
        pbec.display4(ev.getS4());
        pbec.display5(ev.getS5());
        pbec.display6(ev.getS6());
        
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void setP7(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("PBookEvent.fxml"));
        root = loader.load();
        PBookEventController pbec = loader.getController();
        
        pbec.displayPlace("Biomedical Museum");
        Event ev = new Event(st.getUsername());
        
        pbec.displayDistance(String.format("%.2f", dist.Bio(Double.parseDouble(st.getXCoordinate()), Double.parseDouble(st.getYCoordinate()))));
        
        pbec.display1(ev.getS1());
        pbec.display2(ev.getS2());
        pbec.display3(ev.getS3());
        pbec.display4(ev.getS4());
        pbec.display5(ev.getS5());
        pbec.display6(ev.getS6());
        
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void setP8(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("PBookEvent.fxml"));
        root = loader.load();
        PBookEventController pbec = loader.getController();
        
        pbec.displayPlace("Telegraph Museum");
        Event ev = new Event(st.getUsername());
        
        pbec.displayDistance(String.format("%.2f", dist.Tele(Double.parseDouble(st.getXCoordinate()), Double.parseDouble(st.getYCoordinate()))));
        
        pbec.display1(ev.getS1());
        pbec.display2(ev.getS2());
        pbec.display3(ev.getS3());
        pbec.display4(ev.getS4());
        pbec.display5(ev.getS5());
        pbec.display6(ev.getS6());
        
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void setP9(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("PBookEvent.fxml"));
        root = loader.load();
        PBookEventController pbec = loader.getController();
        
        pbec.displayPlace("Penang Science Cluster");
        Event ev = new Event(st.getUsername());
        
        pbec.displayDistance(String.format("%.2f", dist.Penang(Double.parseDouble(st.getXCoordinate()), Double.parseDouble(st.getYCoordinate()))));
        
        pbec.display1(ev.getS1());
        pbec.display2(ev.getS2());
        pbec.display3(ev.getS3());
        pbec.display4(ev.getS4());
        pbec.display5(ev.getS5());
        pbec.display6(ev.getS6());
        
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
//    private String[] time()
//    {
//        String[] slot = new String[6];
//        try
//        {
//            Scanner sc = new Scanner(new FileInputStream("Slot.txt"));
//            
//            for(int i = 0; i<6; i++)
//            {
//               slot[i]=sc.nextLine();
//            }
//            
//            return slot;
//        }
//        catch(IOException e)
//        {
//            System.out.println("failed");
//        }
//        return null;
//    }
}

