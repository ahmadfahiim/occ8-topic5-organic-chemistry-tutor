/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

/**
 *
 * @author User
 */
public class Distance {
    
    public double PetroSc(double x, double y)
    {
        return Math.sqrt(Math.pow(x - (-133.24), 2) + Math.pow(y - (-12.33), 2));
    }
    public double Tech(double x, double y)
    {
        return Math.sqrt(Math.pow(x - (20.87), 2) + Math.pow(y - (9.63), 2));
    }
    public double Agro(double x, double y)
    {
        return Math.sqrt(Math.pow(x - (-23.28), 2) + Math.pow(y - (16.55), 2));
    }
    public double National(double x, double y)
    {
        return Math.sqrt(Math.pow(x - (-90.02), 2) + Math.pow(y - (226.48), 2));
    }
    public double Marine(double x, double y)
    {
        return Math.sqrt(Math.pow(x - (27.51), 2) + Math.pow(y - (-136.98), 2));
    }
    public double Pusat(double x, double y)
    {
        return Math.sqrt(Math.pow(x - (263.99), 2) + Math.pow(y - (-57.31), 2));
    }
    public double Bio(double x, double y)
    {
        return Math.sqrt(Math.pow(x - (96.68), 2) + Math.pow(y - (127.54), 2));
    }
    public double Tele(double x, double y)
    {
        return Math.sqrt(Math.pow(x - (7.02), 2) + Math.pow(y - (-359.28), 2));
    }
    public double Penang(double x, double y)
    {
        return Math.sqrt(Math.pow(x - (21.33), 2) + Math.pow(y - (-0.59), 2));
    }
    
}
