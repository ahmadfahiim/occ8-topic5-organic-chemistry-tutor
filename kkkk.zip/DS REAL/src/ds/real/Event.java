/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Event {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/parent";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "poimpaanoraiadli";
    
    public Event(String username) {
        
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String slot1 = null;
        String slot2 = null;
        String slot3 = null;
        String slot4 = null;
        String slot5 = null;
        String slot6 = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            String selectQuery = "SELECT * FROM book WHERE parent = ?";

            pstmt = con.prepareStatement(selectQuery);
            pstmt.setString(1, username);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                slot1 = rs.getString("s1");
                slot2 = rs.getString("s2");
                slot3 = rs.getString("s3");
                slot4 = rs.getString("s4");
                slot5 = rs.getString("s5");
                slot6 = rs.getString("s6");
                
            } else {
                System.out.println("No user found with username: " + username);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        try
        {
            PrintWriter write = new PrintWriter(new FileWriter("Event.txt"));
            write.print(slot1+","+slot2+","+slot3+","+slot4+","+slot5+","+slot6);
            
            write.close();
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
    }
    
    public Event()
    {
        
    }
    
    public String getS1()
    {
        try
        {
            Scanner sc = new Scanner(new FileInputStream("Event.txt"));
            String read=sc.nextLine();
            String[] arr = read.split(",");
            String slot1 = arr[0];
            
            sc.close();
            return slot1;
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        
        return null;
    }

    public String getS2()
    {
        try
        {
            Scanner sc = new Scanner(new FileInputStream("Event.txt"));
            String read=sc.nextLine();
            String[] arr = read.split(",");
            String slot2 = arr[1];
            
            sc.close();
            return slot2;
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        
        return null;
    }
   
    public String getS3()
    {
        try
        {
            Scanner sc = new Scanner(new FileInputStream("Event.txt"));
            String read=sc.nextLine();
            String[] arr = read.split(",");
            String slot1 = arr[2];
            
            sc.close();
            return slot1;
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        
        return null;
    }
    
    public String getS4()
    {
        try
        {
            Scanner sc = new Scanner(new FileInputStream("Event.txt"));
            String read=sc.nextLine();
            String[] arr = read.split(",");
            String slot1 = arr[3];
            
            sc.close();
            return slot1;
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        
        return null;
    }
    
    public String getS5()
    {
        try
        {
            Scanner sc = new Scanner(new FileInputStream("Event.txt"));
            String read=sc.nextLine();
            String[] arr = read.split(",");
            String slot1 = arr[4];
            
            sc.close();
            return slot1;
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        
        return null;
    }
    
    public String getS6()
    {
        try
        {
            Scanner sc = new Scanner(new FileInputStream("Event.txt"));
            String read=sc.nextLine();
            String[] arr = read.split(",");
            String slot1 = arr[5];
            
            sc.close();
            return slot1;
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        
        return null;
    }
}
