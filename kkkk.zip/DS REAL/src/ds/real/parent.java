/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class parent {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/parent";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "poimpaanoraiadli";
    
    public parent(String username) {
        
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String em = null;
        double x = 0.0, y = 0.0;
        int point = 0;
        
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish Connection
            con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Create SQL Select Query
            String selectQuery = "SELECT * FROM users WHERE username = ?";

            // Create PreparedStatement
            pstmt = con.prepareStatement(selectQuery);
            pstmt.setString(1, username);

            // Execute Select Query
            rs = pstmt.executeQuery();

            if (rs.next()) {
                // Process and print the result
                String email = rs.getString("email");
                double xCoordinate = rs.getDouble("x_coordinate");
                double yCoordinate = rs.getDouble("y_coordinate");
                em=email;
                x=xCoordinate;
                y=yCoordinate;
            } else {
                System.out.println("No user found with username: " + username);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        try
        {
            PrintWriter write = new PrintWriter(new FileWriter("temp.txt"));
            write.print(username + "," + em + "," + x + "," + y + "," + point);
            
            write.close();
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
    }
    
    public parent()
    {
        
    }
    
    public String getUsername()
    {
        try
        {
            Scanner sc = new Scanner(new FileInputStream("temp.txt"));
            String read=sc.nextLine();
            String[] arr = read.split(",");
            String username = arr[0];
            
            System.out.println(username);
            sc.close();
            return username;
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        
        return null;
    }

    public String getEmail()
    {
        try
        {
            Scanner sc = new Scanner(new FileInputStream("temp.txt"));
            String read=sc.nextLine();
            String[] arr = read.split(",");
            String email = arr[1];
            
            sc.close();
            return email;
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        
        return null;
    }
    
    public String getXCoordinate()
    {
        try
        {
            Scanner sc = new Scanner(new FileInputStream("temp.txt"));
            String read=sc.nextLine();
            String[] arr = read.split(",");
            Double xTemp = Double.valueOf(arr[2]);
            String x = String.format("%.2f", xTemp);
            
            sc.close();
            return x;
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        
        return null;
    }
    
    public String getYCoordinate()
    {
        try
        {
            Scanner sc = new Scanner(new FileInputStream("temp.txt"));
            String read=sc.nextLine();
            String[] arr = read.split(",");
            Double yTemp = Double.valueOf(arr[3]);
            String y = String.format("%.2f", yTemp);
            
            sc.close();
            return y;
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        
        return null;
    }
    
    
}
