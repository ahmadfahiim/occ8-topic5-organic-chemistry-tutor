/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

import java.io.IOException;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import java.sql.*;

/**
 *
 * @author User
 */
public class PBookEventController {
    
    @FXML
    Label place;
    @FXML
    Label distanceLabel;
    @FXML
    Label slot1;
    @FXML
    Label slot2;
    @FXML
    Label slot3;
    @FXML
    Label slot4;
    @FXML
    Label slot5;
    @FXML
    Label slot6;
    
    private Stage stage;
    private Scene scene;
    private Parent root;
   
    
    public void displayPlace(String place)
    {
        this.place.setText(place);
    }
    public void displayDistance(String distance)
    {
        this.distanceLabel.setText(distance + " KM");
    }
    public void display1(String slot1)
    {
        this.slot1.setText(slot1);
    }
    public void display2(String slot2)
    {
        this.slot2.setText(slot2);
    }
    public void display3(String slot3)
    {
        this.slot3.setText(slot3);
    }
    public void display4(String slot4)
    {
        this.slot4.setText(slot4);
    }
    public void display5(String slot5)
    {
        this.slot5.setText(slot5);
    }
    public void display6(String slot6)
    {
        this.slot6.setText(slot6);
    }
    
    @FXML
    public void backButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("PEventPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void b1(ActionEvent event) throws IOException
    {
        Connection con = null;
        PreparedStatement pstmt = null;
        
        try {
            parent st = new parent();
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/parent", "root", "poimpaanoraiadli");
            String update = "UPDATE book SET s1 = NULL WHERE parent = ?";
            pstmt = con.prepareStatement(update);
            pstmt.setString(1,st.getUsername());
            int rowsUpdated = pstmt.executeUpdate();
            
            if (rowsUpdated > 0) {
                System.out.println("updated");
                root = FXMLLoader.load(getClass().getResource("PEventPage.fxml"));
                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            }
            else {
                System.out.println("not updated");
            }
            } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }
    
//    @FXML
//    public void cancelb1(ActionEvent event) throws IOException
//    {
//        Connection con = null;
//        PreparedStatement pstmt = null;
//        
//        try {
//            parent st = new parent();
//            Class.forName("com.mysql.cj.jdbc.Driver");
//            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/parent", "root", "poimpaanoraiadli");
//            String update = "UPDATE book SET s1 = NULL WHERE parent = ?";
//            pstmt = con.prepareStatement(update);
//            pstmt.setString(1,);
//            int rowsUpdated = pstmt.executeUpdate();
//            
//            if (rowsUpdated > 0) {
//                System.out.println("updated");
//                root = FXMLLoader.load(getClass().getResource("PEventPage.fxml"));
//                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
//                scene = new Scene(root);
//                stage.setScene(scene);
//                stage.show();
//            }
//            else {
//                System.out.println("not updated");
//            }
//            } catch (ClassNotFoundException | SQLException e) {
//            System.out.println(e.getMessage());
//        } finally {
//            try {
//                if (pstmt != null) pstmt.close();
//                if (con != null) con.close();
//            } catch (SQLException e) {
//                System.out.println(e.getMessage());
//            }
//        }
//    }
}
