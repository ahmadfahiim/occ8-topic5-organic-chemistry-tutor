/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

import java.sql.Statement;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 *
 * @author User
 */
public class SQuizPageController {
    @FXML
    private TableView<ObservableList<String>> quizTable;
    @FXML
    private TableColumn<ObservableList<String>, String> titleColumn;
    @FXML
    private TableColumn<ObservableList<String>, String> descriptionColumn;
    @FXML
    private TableColumn<ObservableList<String>, String> themeColumn;
    @FXML
    private TableColumn<ObservableList<String>, String> contentColumn;
    
    @FXML
    private CheckBox scienceCheckBox;
    @FXML
    private CheckBox technologyCheckBox;
    @FXML
    private CheckBox engineeringCheckBox;
    @FXML
    private CheckBox mathematicsCheckBox;
    @FXML
    private TextField nameOfQuiz;

    private ObservableList<ObservableList<String>> quizList = FXCollections.observableArrayList();
    
    Student st = new Student();
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    @FXML
    public void viewProfileButton(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("SMainScreen.fxml"));
        root = loader.load();

        SMainScreenController smsc = loader.getController();
        smsc.displayName(st.getUsername());
        smsc.displayEmail(st.getEmail());
        smsc.displayX(st.getXCoordinate());
        smsc.displayY(st.getYCoordinate());
        smsc.displayPoint(st.getPoint());
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void eventPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SEventPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void discussionPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SDiscussionPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void logoutButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("Landing.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void initialize() {
        titleColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().get(0)));
        descriptionColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().get(1)));
        themeColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().get(2)));
        contentColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().get(2)));
        
        loadQuizData();
    }
    
    private void loadQuizData() {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/event", "root", "poimpaanoraiadli");
            String query = "SELECT title, description, theme, content FROM quizzes";

            stmt = con.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                ObservableList<String> row = FXCollections.observableArrayList();
                row.add(rs.getString("title"));
                row.add(rs.getString("description"));
                row.add(rs.getString("theme"));
                row.add(rs.getString("content"));

                quizList.add(row);
            }

            // Set Data to TableView
            quizTable.setItems(quizList);

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    @FXML
    private void filterQuizzes(ActionEvent event) {
        ObservableList<ObservableList<String>> filteredList = FXCollections.observableArrayList();

        for (ObservableList<String> quiz : quizList) {
            String theme = quiz.get(2);
            if ((scienceCheckBox.isSelected() && theme.equalsIgnoreCase("science")) ||
                (technologyCheckBox.isSelected() && theme.equalsIgnoreCase("technology")) ||
                (engineeringCheckBox.isSelected() && theme.equalsIgnoreCase("engineering")) ||
                (mathematicsCheckBox.isSelected() && theme.equalsIgnoreCase("mathematics"))) {
                filteredList.add(quiz);
            }
        }

        quizTable.setItems(filteredList);
    }
    
    @FXML
    public void submit(ActionEvent Event) throws IOException
    {
        String event = nameOfQuiz.getText();
        try {
            Connection con = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;

            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/event", "root", "poimpaanoraiadli");
            String query = "SELECT * FROM quizzes WHERE title = ?";

            pstmt = con.prepareStatement(query);
            pstmt.setString(1, event);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("event succesfully registered");
                
                intoSql(event);
                this.updatepoint();
            } else {
                System.out.println("failed");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void intoSql(String quiz)
    {
        try {
            Connection con = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "poimpaanoraiadli");
            String query = "INSERT INTO quizzes (username, quiz) VALUES (?, ?)";

            Student st = new Student();
            String username =  st.getUsername();

            pstmt = con.prepareStatement(query);
            pstmt.setString(1, username);
            pstmt.setString(2, quiz);
            
            int rowsInserted = pstmt.executeUpdate();

            if (rowsInserted > 0) {
                System.out.println("event succesfully registered");
            } else {
                System.out.println("failed2");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void updatepoint() {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "poimpaanoraiadli");

            String selectQuery = "SELECT * FROM users WHERE username = ?";
            String updateQuery = "UPDATE users SET current_points = ? WHERE username = ?";

            Student st = new Student();
            pstmt = con.prepareStatement(selectQuery);
            pstmt.setString(1, st.getUsername());

            rs = pstmt.executeQuery();

            if (rs.next()) {
                int point = rs.getInt("current_points");
                point += 2;

                pstmt = con.prepareStatement(updateQuery);
                pstmt.setInt(1, point);
                pstmt.setString(2, st.getUsername());

                int rowsUpdated = pstmt.executeUpdate();

                if (rowsUpdated > 0) {
                    System.out.println("User points updated successfully!");
                } else {
                    System.out.println("Failed to update user points.");
                }
            } else {
                System.out.println("No user found with username: " + st.getUsername());
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
