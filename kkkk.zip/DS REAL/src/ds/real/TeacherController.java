/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author User
 */
public class TeacherController {
    
    @FXML
    private Button cancelButton;
    @FXML
    private Button registerButton;
    @FXML
    private TextField emailField;
    @FXML
    public TextField usernameField;
    @FXML
    private TextField passwordField;
    @FXML
    private Button login;
    
    private Stage stage;
    private Scene scene;
    private Parent root;
   
    
    @FXML
    public void back(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("Landing.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void cancel(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("TLogin.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void toRegister(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("TRegister.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void registerButton(ActionEvent event) throws IOException {
        
            try {
            Connection con = null;
            PreparedStatement pstmt = null;
            String email = emailField.getText();
            String username = usernameField.getText();
            String password = passwordField.getText();

            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");  

            // Establish Connection
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/teacher", "root", "poimpaanoraiadli"); 

            // Create SQL Insert Query
            String insertQuery = "INSERT INTO users (email, username, password) VALUES (?, ?, ?)";

            // Create PreparedStatement
            pstmt = con.prepareStatement(insertQuery);
            pstmt.setString(1, email);
            pstmt.setString(2, username);
            pstmt.setString(3, password);

            // Execute Insert Query
            int rowsInserted = pstmt.executeUpdate();

            if (rowsInserted > 0) {
                System.out.println("A new user was inserted successfully!");
                root = FXMLLoader.load(getClass().getResource("TLogin.fxml"));
                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
//        } finally {
//            // Close resources
//            try {
//                if (pstmt != null) pstmt.close();
//                if (con != null) con.close();
//            } catch (SQLException e) {
//                System.out.println(e.getMessage());
//            }
        }
    }
    
    @FXML
    public void loginButton(ActionEvent event) throws IOException {
        try {
            Connection con = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            String username = usernameField.getText();
            String password = passwordField.getText();

            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/teacher", "root", "poimpaanoraiadli");
            String selectQuery = "SELECT * FROM users WHERE username = ? AND password = ?";

            pstmt = con.prepareStatement(selectQuery);
            pstmt.setString(1, username);
            pstmt.setString(2, password);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Login successful!");
                
                Teacher st = new Teacher(username);
                FXMLLoader loader = new FXMLLoader(getClass().getResource("TMainScreen.fxml"));
                root = loader.load();
                String em = st.getEmail();
                String num = st.getEvents();
                String num2 = st.getQuiz();
                TMainScreenController smsc = loader.getController();
                smsc.displayName(username);
                smsc.displayEmail(em);
                smsc.displayEvent(num);
                smsc.displayQuiz(num2);
                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            } else {
                System.out.println("Login failed. Username or password is incorrect.");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
//        } finally {
//            // Close resources
//            try {
//                if (rs != null) rs.close();
//                if (pstmt != null) pstmt.close();
//                if (con != null) con.close();
//            } catch (SQLException e) {
//                System.out.println(e.getMessage());
//            }
        }
    }
    
}
