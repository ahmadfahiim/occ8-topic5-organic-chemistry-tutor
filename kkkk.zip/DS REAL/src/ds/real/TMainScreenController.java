/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author User
 */ 

public class TMainScreenController {
    TeacherController tc = new TeacherController();
    
//    @FXML
//    private TableView<ObservableList<Object>> userTable;
//    @FXML
//    private TableColumn<ObservableList<Object>, String> emailColumn;
//    @FXML
//    private TableColumn<ObservableList<Object>, String> usernameColumn;
    
    
    private Stage stage;
    private Scene scene;
    private Parent root;
   private int numEvent;
    
    @FXML
    private Label usernameLabel;
    @FXML
    private Label emailLabel;
    @FXML
    private Label numOfEventLabel;
    @FXML
    private Label numOfQuizLabel;

    public void displayName(String username)
    {
        usernameLabel.setText(username);
    }
    public void displayEmail(String email)
    {
        emailLabel.setText(email);
    }
    public void displayEvent(String label)
    {
        numOfEventLabel.setText(label);
    }
    public void displayQuiz(String label)
    {
        numOfQuizLabel.setText(label);
    }
    
    @FXML
    public void eventPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("TEventPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void discussionPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("TDiscussionPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void quizPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("TQuizPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void logoutButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("Landing.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    public void setNumEvent(int numEvent){
        this.numEvent=numEvent;
    }
//    @FXML
//    public void initialize() {
//        emailColumn.setCellValueFactory(cellData -> new SimpleStringProperty((String) cellData.getValue().get(0)));
//        usernameColumn.setCellValueFactory(cellData -> new SimpleStringProperty((String) cellData.getValue().get(1)));
//        loadUserData();
//    }
//    
//     private void loadUserData() {
//       ObservableList<ObservableList<Object>> userList = FXCollections.observableArrayList();
//
//        Connection con = null;
//        Statement stmt = null;
//
//        try {
//            // Load MySQL JDBC Driver
//            Class.forName("com.mysql.cj.jdbc.Driver");
//
//            // Establish Connection
//            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "poimpaanoraiadli");
//
//            // Create SQL Query
//            String query = "SELECT email, username FROM users";
//
//            // Execute Query
//            stmt = con.createStatement();
//            ResultSet rs = stmt.executeQuery(query);
//
//            // Process Result Set
//            while (rs.next()) {
//                ObservableList<Object> row = FXCollections.observableArrayList();
//                row.add(rs.getString("email"));
//                row.add(rs.getString("username"));
//                
//                userList.add(row);
//            }
//
//            // Set Data to TableView
//            userTable.setItems(userList);
//
//        } catch (ClassNotFoundException | SQLException e) {
//            e.printStackTrace();
//        } finally {
//            // Close resources
//            try {
//                if (stmt != null) stmt.close();
//                if (con != null) con.close();
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//        }
//    }
}
