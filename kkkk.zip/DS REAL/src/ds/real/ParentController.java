/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.Random;

/**
 *
 * @author User
 */
public class ParentController {
    
    @FXML
    private Button cancelButton;
    @FXML
    private Button registerButton;
    @FXML
    private TextField emailField;
    @FXML
    private TextField usernameField;
    @FXML
    private TextField passwordField;
    @FXML
    private Button login;
    
    private Stage stage;
    private Scene scene;
    private Parent root;
   
    
    @FXML
    public void back(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("Landing.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void cancel(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("PLogin.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void toRegister(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("PRegister.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
public void registerButton(ActionEvent event) throws IOException {
    Connection con = null;
    PreparedStatement pstmt = null;
    try {
        String email = emailField.getText();
        String username = usernameField.getText();
        String password = passwordField.getText();
        double xCoordinate = -500.00 + (Math.random() * 1000.00);
        double yCoordinate = -500.00 + (Math.random() * 1000.00);
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/parent", "root", "poimpaanoraiadli");
        String insertUserQuery = "INSERT INTO users (email, username, password, x_coordinate, y_coordinate) VALUES (?, ?, ?, ?, ?)";

        pstmt = con.prepareStatement(insertUserQuery);
        pstmt.setString(1, email);
        pstmt.setString(2, username);
        pstmt.setString(3, password);
        pstmt.setDouble(4, xCoordinate);
        pstmt.setDouble(5, yCoordinate);

        int rowsInserted = pstmt.executeUpdate();

        if (rowsInserted > 0) {
            System.out.println("A new user was inserted successfully!");
            root = FXMLLoader.load(getClass().getResource("PLogin.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();

            LocalDate baseDate = getRandomDate();
            
            LocalDate date1 = baseDate;
            LocalDate date2 = baseDate.plusDays(7);
            LocalDate date3 = baseDate.plusDays(14);
            LocalDate date4 = baseDate.plusDays(21);
            LocalDate date5 = baseDate.plusDays(28);
            LocalDate date6 = baseDate.plusDays(35);

            String insertBookQuery = "INSERT INTO book (parent, children, s1, s2, s3, s4, s5, s6) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            pstmt = con.prepareStatement(insertBookQuery);
            pstmt.setString(1, username);
            pstmt.setString(2, "null");
            pstmt.setDate(3, java.sql.Date.valueOf(date1));
            pstmt.setDate(4, java.sql.Date.valueOf(date2));
            pstmt.setDate(5, java.sql.Date.valueOf(date3));
            pstmt.setDate(6, java.sql.Date.valueOf(date4));
            pstmt.setDate(7, java.sql.Date.valueOf(date5));
            pstmt.setDate(8, java.sql.Date.valueOf(date6));

            rowsInserted = pstmt.executeUpdate();

            if (rowsInserted > 0) {
                System.out.println("A new entry was inserted into the book table successfully!");
            }
        }
    } catch (ClassNotFoundException | SQLException e) {
        System.out.println(e.getMessage());
    } finally {
        try {
            if (pstmt != null) pstmt.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}

    
    @FXML
    public void loginButton(ActionEvent event) throws IOException {
        
            Connection con = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;
        try {
            String username = usernameField.getText();
            String password = passwordField.getText();

            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/parent", "root", "poimpaanoraiadli");
            String selectQuery = "SELECT * FROM users WHERE username = ? AND password = ?";

            pstmt = con.prepareStatement(selectQuery);
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Login successful!");
                parent st = new parent(username);
                FXMLLoader loader = new FXMLLoader(getClass().getResource("PMainScreen.fxml"));
                root = loader.load();
                String em = st.getEmail();
                String x = st.getXCoordinate();
                String y = st.getYCoordinate();
                PMainScreenController smsc = loader.getController();
                smsc.displayName(username);
                smsc.displayEmail(em);
                smsc.displayX(x);
                smsc.displayY(y);
                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
                
            } else {
                System.out.println("Login failed. Username or password is incorrect.");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }
    
    private LocalDate getRandomDate() {
        Random random = new Random();
        int minDay = (int) LocalDate.of(2024, 9, 1).toEpochDay();
        int maxDay = (int) LocalDate.of(2024, 12, 31).toEpochDay();
        long randomDay = minDay + random.nextInt(maxDay - minDay);

        return LocalDate.ofEpochDay(randomDay);
    }
}
