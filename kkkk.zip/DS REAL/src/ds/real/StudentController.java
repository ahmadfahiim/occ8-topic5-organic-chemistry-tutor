/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author User
 */
public class StudentController {
    
    @FXML
    private TextField emailField;
    @FXML
    private TextField usernameField;
    @FXML
    private TextField passwordField;
        
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    public void back(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("Landing.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    public void cancel(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SLogin.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    public void toRegister(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SRegister.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    public void registerButton(ActionEvent event) throws IOException {
        Connection con = null;
        PreparedStatement pstmt = null;
        try {
            String email = emailField.getText();
            String username = usernameField.getText();
            String password = passwordField.getText();
            double xCoordinate = -500.00 + (Math.random() * 1000.00);
            double yCoordinate = -500.00 + (Math.random() * 1000.00);
            int initialPoints = 0;

            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "poimpaanoraiadli");
            String insertQuery = "INSERT INTO users (email, username, password, x_coordinate, y_coordinate, current_points) VALUES (?, ?, ?, ?, ?, ?)";

            pstmt = con.prepareStatement(insertQuery);
            pstmt.setString(1, email);
            pstmt.setString(2, username);
            pstmt.setString(3, password);
            pstmt.setDouble(4, xCoordinate);
            pstmt.setDouble(5, yCoordinate);
            pstmt.setInt(6, initialPoints);

            int rowsInserted = pstmt.executeUpdate();

            if (rowsInserted > 0) {
                System.out.println("A new user was inserted successfully!");
                root = FXMLLoader.load(getClass().getResource("SLogin.fxml"));
                stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }
    
    public void setUsername(String username) {}
    
    @FXML
    public void loginButton(ActionEvent event) throws IOException {
        try {
            Connection con = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            String username = usernameField.getText();
            String password = passwordField.getText();

            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "poimpaanoraiadli");
            String selectQuery = "SELECT * FROM users WHERE username = ? AND password = ?";

            pstmt = con.prepareStatement(selectQuery);
            pstmt.setString(1, username);
            pstmt.setString(2, password);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Login successful!");
                
                Student st = new Student(username);
                FXMLLoader loader = new FXMLLoader(getClass().getResource("SMainScreen.fxml"));
                root = loader.load();
                String em = st.getEmail();
                String x = st.getXCoordinate();
                String y = st.getYCoordinate();
                String point = st.getPoint();
                SMainScreenController smsc = loader.getController();
                
                smsc.displayName(username);
                smsc.displayEmail(em);
                smsc.displayX(x);
                smsc.displayY(y);
                smsc.displayPoint(point);
                
                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            } else {
                System.out.println("Login failed. Username or password is incorrect.");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
//        } finally {
//            // Close resources
//            try {
//                if (rs != null) rs.close();
//                if (pstmt != null) pstmt.close();
//                if (con != null) con.close();
//            } catch (SQLException e) {
//                System.out.println(e.getMessage());
//            }
        }
    }
    
    
    
}
