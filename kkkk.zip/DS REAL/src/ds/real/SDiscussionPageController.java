/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

import java.sql.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 *
 * @author User
 */
public class SDiscussionPageController {
    
    @FXML
    private TableView<ObservableList<String>> studentTable;
    @FXML
    private TableColumn<ObservableList<String>, String> usernameColumn;
    @FXML
    private TableColumn<ObservableList<String>, String> currentPointsColumn;

    
    private Stage stage;
    private Scene scene;
    private Parent root;
    Student st = new Student();
    
    @FXML
    public void initialize() {
        usernameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().get(0)));
        currentPointsColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().get(1)));

        loadStudentData();
    }
    
    @FXML
    public void viewProfileButton(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("SMainScreen.fxml"));
        root = loader.load();

        SMainScreenController smsc = loader.getController();
        smsc.displayName(st.getUsername());
        smsc.displayEmail(st.getEmail());
        smsc.displayX(st.getXCoordinate());
        smsc.displayY(st.getYCoordinate());
        smsc.displayPoint(st.getPoint());
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void eventPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SEventPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void discussionPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SDiscussionPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void quizPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SQuizPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();        
    }
    
    @FXML
    public void logoutButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("Landing.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    private void loadStudentData() {
        ObservableList<ObservableList<String>> studentList = FXCollections.observableArrayList();

        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "poimpaanoraiadli");
            String query = "SELECT username, current_points FROM users ORDER BY current_points DESC";
            
            stmt = con.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                ObservableList<String> row = FXCollections.observableArrayList();
                row.add(rs.getString("username"));
                row.add(String.valueOf(rs.getInt("current_points")));

                studentList.add(row);
            }

            studentTable.setItems(studentList);

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
