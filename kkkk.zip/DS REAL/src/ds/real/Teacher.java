/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Teacher {
    private String username;
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/teacher";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "poimpaanoraiadli";
    
    public Teacher(String username) {
        
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String em = null;
        double x = 0.0, y = 0.0;
        int point = 0;
        
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish Connection
            con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Create SQL Select Query
            String selectQuery = "SELECT * FROM users WHERE username = ?";

            // Create PreparedStatement
            pstmt = con.prepareStatement(selectQuery);
            pstmt.setString(1, username);

            // Execute Select Query
            rs = pstmt.executeQuery();

            if (rs.next()) {
                String email = rs.getString("email");
                em=email;
            } else {
                System.out.println("No user found with username: " + username);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        try
        {
            PrintWriter write = new PrintWriter(new FileWriter("temp.txt"));
            write.print(username + "," + em);
            
            write.close();
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
    }
    
    public Teacher()
    {
        
    }
    
    public String getUsername()
    {
        try
        {
            Scanner sc = new Scanner(new FileInputStream("temp.txt"));
            String read=sc.nextLine();
            String[] arr = read.split(",");
            String username = arr[0];
            
            System.out.println(username);
            sc.close();
            return username;
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        
        return null;
    }

    public String getEmail()
    {
        try
        {
            Scanner sc = new Scanner(new FileInputStream("temp.txt"));
            String read=sc.nextLine();
            String[] arr = read.split(",");
            String email = arr[1];
            
            sc.close();
            return email;
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        
        return null;
    }
    
    public String getEvents() {
        TEventPageController tepc = new TEventPageController();
        String num = Integer.toString(tepc.getRowCount());
        try
        {
            PrintWriter write = new PrintWriter(new FileWriter("temp2.txt"));
            write.print(num);
            
            write.close();
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        try
        {
            Scanner sc = new Scanner(new FileInputStream("temp2.txt"));
            String read=sc.nextLine();
            
            sc.close();
            return num;
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        
        return null;
    }
    
    public String getQuiz() {
        TQuizPageController tqpc = new TQuizPageController();
        String num = Integer.toString(tqpc.getRowCount());
        try
        {
            PrintWriter write = new PrintWriter(new FileWriter("temp3.txt"));
            write.print(num);
            
            write.close();
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        try
        {
            Scanner sc = new Scanner(new FileInputStream("temp3.txt"));
            String read=sc.nextLine();
            
            sc.close();
            return num;
        }
        catch(IOException e)
        {
            System.out.println("File not created");
        }
        
        return null;
    }
}
