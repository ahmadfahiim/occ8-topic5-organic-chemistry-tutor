/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.sql.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
/**
 *
 * @author User
 */
public class TQuizPageController {
    @FXML
    private TextField quizTitleField;
    @FXML
    private TextArea quizDescriptionField;
    @FXML
    private TextField quizThemeField;
    @FXML
    private TextField quizContentField;
    @FXML
    private TableView<ObservableList<String>> eventTable;
    @FXML
    private TableColumn<ObservableList<String>, String> titleColumn;
    @FXML
    private TableColumn<ObservableList<String>, String> descriptionColumn;
    @FXML
    private TableColumn<ObservableList<String>, String> themeColumn;
    @FXML
    private TableColumn<ObservableList<String>, String> contentColumn;
    
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    Teacher st = new Teacher();
    
    @FXML
    public void viewProfileButton(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("TMainScreen.fxml"));
        root = loader.load();

        TMainScreenController smsc = loader.getController();
        smsc.displayName(st.getUsername());
        smsc.displayEmail(st.getEmail());
        smsc.displayEvent(st.getEvents());
        smsc.displayQuiz(st.getQuiz());
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void eventPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("TEventPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        
        
    }
    
    @FXML
    public void discussionPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("TDiscussionPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void logoutButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("Landing.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void initialize() {
        titleColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().get(0)));
        descriptionColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().get(1)));
        themeColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().get(2)));
        contentColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().get(3)));

        loadQuizData();
    }
    
    private void loadQuizData() {
        ObservableList<ObservableList<String>> eventList = FXCollections.observableArrayList();

        Connection con = null;
        Statement stmt = null;

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish Connection
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/event", "root", "poimpaanoraiadli");

            // Create SQL Query
            String query = "SELECT title, description, theme, content FROM quizzes";

            // Execute Query
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            // Process Result Set
            while (rs.next()) {
                ObservableList<String> row = FXCollections.observableArrayList();
                row.add(rs.getString("title"));
                row.add(rs.getString("description"));
                row.add(rs.getString("theme"));
                row.add(rs.getString("content"));

                eventList.add(row);
            }

            // Set Data to TableView
            eventTable.setItems(eventList);

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    @FXML
    public void createQuizButton(ActionEvent event) {
        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            String title = quizTitleField.getText();
            String description = quizDescriptionField.getText();
            String theme = quizThemeField.getText();
            String content = quizContentField.getText();

            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish Connection
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/event", "root", "poimpaanoraiadli");

            // Create SQL Insert Query
            String insertQuery = "INSERT INTO quizzes (title, description, theme, content) VALUES (?, ?, ?, ?)";

            // Create PreparedStatement
            pstmt = con.prepareStatement(insertQuery);
            pstmt.setString(1, title);
            pstmt.setString(2, description);
            pstmt.setString(3, theme);
            pstmt.setString(4, content);

            // Execute Insert Query
            int rowsInserted = pstmt.executeUpdate();

            if (rowsInserted > 0) {
                System.out.println("A new quiz was inserted successfully!");
                // Optionally, clear the fields after successful insertion
                quizTitleField.clear();
                quizDescriptionField.clear();
                quizThemeField.clear();
                quizContentField.clear();
                
                loadQuizData();
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    @FXML
    public void deleteSelectedQuiz(ActionEvent event) {
        Connection con = null;
        PreparedStatement pstmt = null;

        // Get the selected item
        ObservableList<String> selectedQuiz = eventTable.getSelectionModel().getSelectedItem();
        ObservableList<ObservableList<String>> eventList = FXCollections.observableArrayList();

        if (selectedQuiz != null) {
            String title = selectedQuiz.get(0);

            try {
                // Load MySQL JDBC Driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Establish Connection
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/event", "root", "poimpaanoraiadli");

                // Create SQL Delete Query
                String deleteQuery = "DELETE FROM quizzes WHERE title = ?";

                // Create PreparedStatement
                pstmt = con.prepareStatement(deleteQuery);
                pstmt.setString(1, title);

                // Execute Delete Query
                int rowsDeleted = pstmt.executeUpdate();

                if (rowsDeleted > 0) {
                    System.out.println("The quiz was deleted successfully!");

                    // Remove the selected item from the TableView
                    eventList.remove(selectedQuiz);
                }
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            } finally {
                // Close resources
                try {
                    if (pstmt != null) pstmt.close();
                    if (con != null) con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("No quiz selected!");
        }
    }
    
    public static int getRowCount() {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int rowCount = 0;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/event", "root", "poimpaanoraiadli");
            String countQuery = "SELECT COUNT(*) FROM quizzes";

            pstmt = con.prepareStatement(countQuery);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                rowCount = rs.getInt(1);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return rowCount;
    }
}
