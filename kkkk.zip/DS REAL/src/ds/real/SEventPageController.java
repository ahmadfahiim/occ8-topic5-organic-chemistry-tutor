/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

import java.sql.Statement;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.fxml.Initializable;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 *
 * @author User
 */
public class SEventPageController {
    @FXML
    private TableView<ObservableList<String>> eventTable;
    @FXML
    private TableColumn<ObservableList<String>, String> titleColumn;
    @FXML
    private TableColumn<ObservableList<String>, String> dateColumn;
    @FXML
    private Label liveEventLabel;
    @FXML
    private TextField nameOfEvent;
    
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    Student st = new Student();
    
    @FXML
    public void viewProfileButton(ActionEvent event) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("SMainScreen.fxml"));
        root = loader.load();

        SMainScreenController smsc = loader.getController();
        smsc.displayName(st.getUsername());
        smsc.displayEmail(st.getEmail());
        smsc.displayX(st.getXCoordinate());
        smsc.displayY(st.getYCoordinate());
        smsc.displayPoint(st.getPoint());
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();  
    }
    
    @FXML
    public void discussionPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SDiscussionPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void quizPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SQuizPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();        
    }
    
    @FXML
    public void logoutButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("Landing.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void initialize() {
        titleColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().get(0)));
        dateColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().get(1)));

        loadEventData();
        checkForLiveEvent();
    }
    
    private void loadEventData() {
        ObservableList<ObservableList<String>> eventList = FXCollections.observableArrayList();

        Connection con = null;
        Statement stmt = null;
        PreparedStatement pstmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/event", "root", "poimpaanoraiadli");
            LocalDate currentDate = LocalDate.now();

            String query = "SELECT title, date " +
                           "FROM events " +
                           "WHERE date >= ? " +
                           "ORDER BY date ASC " +
                           "LIMIT 3";

            pstmt = con.prepareStatement(query);
            pstmt.setDate(1, java.sql.Date.valueOf(currentDate));
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                ObservableList<String> row = FXCollections.observableArrayList();
                row.add(rs.getString("title"));
                row.add(rs.getString("date").toString());
                eventList.add(row);
            }
            eventTable.setItems(eventList);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    private void checkForLiveEvent() {
        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/event", "root", "poimpaanoraiadli");
            LocalDate currentDate = LocalDate.now();
            
            String query = "SELECT title FROM events WHERE date = ?";

            pstmt = con.prepareStatement(query);
            pstmt.setDate(1, java.sql.Date.valueOf(currentDate));
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                String liveEventTitle = rs.getString("title");
                liveEventLabel.setText("Live Event: " + liveEventTitle);
            } else {
                liveEventLabel.setText("No live events");
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    @FXML
    public void submit(ActionEvent Event) throws IOException
    {
        String event = nameOfEvent.getText();
        try {
            Connection con = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;

            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/event", "root", "poimpaanoraiadli");
            String query = "SELECT * FROM events WHERE title = ?";

            pstmt = con.prepareStatement(query);
            pstmt.setString(1, event);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("event succesfully registered");
                
                intoSql(event);
                this.updatepoint(5);
            } else {
                System.out.println("failed");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void intoSql(String event)
    {
        try {
            Connection con = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "poimpaanoraiadli");
            String query = "INSERT INTO event (username, event) VALUES (?, ?)";

            Student st = new Student();
            String username =  st.getUsername();

            pstmt = con.prepareStatement(query);
            pstmt.setString(1, username);
            pstmt.setString(2, event);
            
            int rowsInserted = pstmt.executeUpdate();

            if (rowsInserted > 0) {
                System.out.println("event succesfully registered");
            } else {
                System.out.println("failed2");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void updatepoint(int n) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "poimpaanoraiadli");

            // Create SQL Select Query
            String selectQuery = "SELECT * FROM users WHERE username = ?";
            String updateQuery = "UPDATE users SET current_points = ? WHERE username = ?";

            // Create PreparedStatement
            Student st = new Student();
            pstmt = con.prepareStatement(selectQuery);
            pstmt.setString(1, st.getUsername());

            // Execute Select Query
            rs = pstmt.executeQuery();

            if (rs.next()) {
                // Process and print the result
                int point = rs.getInt("current_points");
                point += n;

                // Create a new PreparedStatement for the update
                pstmt = con.prepareStatement(updateQuery);
                pstmt.setInt(1, point);
                pstmt.setString(2, st.getUsername());

                // Execute Update Query
                int rowsUpdated = pstmt.executeUpdate();

                if (rowsUpdated > 0) {
                    System.out.println("User points updated successfully!");
                } else {
                    System.out.println("Failed to update user points.");
                }
            } else {
                System.out.println("No user found with username: " + st.getUsername());
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
