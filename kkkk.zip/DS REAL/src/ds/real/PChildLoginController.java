/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author User
 */
public class PChildLoginController {
    @FXML
    private TextField usernameField;
    @FXML
    private TextField passwordField;
    
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    public void back(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("PMainScreen.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void loginButton(ActionEvent event) throws IOException {
        
            Connection con = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;
        try {
            String username = usernameField.getText();
            String password = passwordField.getText();

            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "poimpaanoraiadli");
            String selectQuery = "SELECT * FROM users WHERE username = ? AND password = ?";

            pstmt = con.prepareStatement(selectQuery);
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Login successful!");
                FXMLLoader loader = new FXMLLoader(getClass().getResource("PMainScreen.fxml"));
                root = loader.load();
                parent st = new parent();
                PMainScreenController smsc = loader.getController();
                smsc.displayName(st.getUsername());
                smsc.displayEmail(st.getEmail());
                smsc.displayX(st.getXCoordinate());
                smsc.displayY(st.getYCoordinate());
                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
                addChild(username);
                
            } else {
                System.out.println("Login failed. Username or password is incorrect.");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    } 

    private void addChild(String username) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/parent", "root", "poimpaanoraiadli");

            // Create SQL Select Query
            String selectQuery = "SELECT * FROM book WHERE parent = ?";
            String updateQuery = "UPDATE book SET children = ? WHERE parent = ?";

            parent st = new parent();
            pstmt = con.prepareStatement(selectQuery);
            pstmt.setString(1, st.getUsername());

            rs = pstmt.executeQuery();
            if (rs.next()) {
                pstmt = con.prepareStatement(updateQuery);
                pstmt.setString(1, username);
                pstmt.setString(2, st.getUsername());

                // Execute Update Query
                int rowsUpdated = pstmt.executeUpdate();

                if (rowsUpdated > 0) {
                    System.out.println("User points updated successfully!");
                } else {
                    System.out.println("Failed to update user points.");
                }
            } else {
                System.out.println("No user found with username: " + st.getUsername());
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
