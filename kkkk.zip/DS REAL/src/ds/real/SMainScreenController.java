/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds.real;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

/**
 *
 * @author User
 */

    public class SMainScreenController {
    
    private Stage stage;
    private Scene scene;
    private Parent root;
   
    @FXML
    Label nameLabel;
    @FXML
    Label emailLabel;
    @FXML
    Label xLabel;
    @FXML
    Label yLabel;
    @FXML
    Label pointLabel;
    
    public void displayName(String username)
    {
        nameLabel.setText(username);
    }
    public void displayEmail(String email)
    {
        emailLabel.setText(email);
    }
    public void displayX(String x)
    {
        xLabel.setText(x);
    }
    public void displayY(String y)
    {
        yLabel.setText(y);
    }
    public void displayPoint(String point)
    {
        pointLabel.setText(point);
    }
    
    
    @FXML
    public void eventPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SEventPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void viewProfileButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SMainScreen.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void discussionPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SDiscussionPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void quizPageButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SQuizPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();        
    }
    
    @FXML
    public void logoutButton(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("Landing.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
